# gulp project
```
cnpm init 
cnpm install gulp 
cnpm install --save-dev gulp.spritesmith
gulp
```